package com.example.businesscontrollv3.repository

import com.example.businesscontrollv3.model.Account
import com.example.businesscontrollv3.model.AccountTypeEnum
import com.example.businesscontrollv3.model.Transaction

class TransactionRepository {

            fun getTransactions(): List<Account>{

            val transaction1 = Transaction()
            val transaction2 = Transaction()

            return listOf(transaction1, transaction2)
        }
    }

}