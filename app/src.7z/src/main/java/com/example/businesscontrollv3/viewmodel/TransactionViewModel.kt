package com.example.businesscontrollv3.viewmodel

import com.example.businesscontrollv3.model.TransactionTypeEnum

class TransactionViewModel {

    class AccountViewModel(val transactionTypeEnum:TransactionTypeEnum):BaseViewModel(){
            val transactionList = transactionTypeEnum.type
    }
}