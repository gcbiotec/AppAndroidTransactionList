package com.example.businesscontrollv3

import android.app.Application
import com.example.businesscontrollv3.infra.database.BCDatabase
import com.example.businesscontrollv3.repository.ResponsibleRepository

class BusinessControllV3 : Application() {

    val database by lazy {BCDatabase.getDatabase(this)}

    val responsibleRepository by lazy{
        ResponsibleRepository(database.responsibleDAO())
    }
}