package com.example.businesscontrollv3.repository

import com.example.businesscontrollv3.model.Account
import com.example.businesscontrollv3.model.AccountTypeEnum

class AccountRepository {

    fun getAccounts(): List<Account>{

        val account1 = Account("banco 1", 22.0 , 1, AccountTypeEnum.DEBITO)
        val account2 = Account("banco 2", 289.0 , 1, AccountTypeEnum.DEBITO)

        return listOf(account1, account2)
    }
}