package com.example.businesscontrollv3.view.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.businesscontrollv3.R
import com.example.businesscontrollv3.model.Account
import kotlinx.android.synthetic.main.item_account.view.*

class AccountAdapter(private val accountList: List<Account>) :
    RecyclerView.Adapter<AccountAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AccountAdapter.ViewHolder {
                    val itemAccount = LayoutInflater.from(parent.context).inflate(R.layout.item_account, parent, false )
                    return ViewHolder(itemAccount)
            }

    override fun onBindViewHolder(holder: AccountAdapter.ViewHolder, position: Int) {
                holder.name.text = accountList[position].name
                holder.type.text = accountList[position].accountType.type
                holder.balance.text = accountList[position].balance.toString()
                holder.response.text = accountList[position].responsibleId.toString()

    }

    override fun getItemCount(): Int = accountList.size

    class ViewHolder (itemAccount: View) : RecyclerView.ViewHolder(itemAccount){
        val name: TextView = itemAccount.findViewById(R.id.nameTV)
        val type: TextView = itemAccount.findViewById(R.id.typeTV)
        val balance: TextView = itemAccount.findViewById(R.id.balanceTV)
        val response: TextView = itemAccount.findViewById(R.id.responsibleTV)


    }
}