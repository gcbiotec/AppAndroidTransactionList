package com.example.businesscontrollv3.model

data class Account(
        var name: String,
        var balance: Double,
        var responsibleId: Int,
        var accountType:  AccountTypeEnum
)
