package com.example.businesscontrollv3.model

import java.util.*

class Transaction {

    lateinit var date: Calendar

    var value2: Double = 0.0

    var description2: String? = null

    lateinit var transactionType2: TransactionTypeEnum

    var idResponsible: Int = 0

    var idAccount2: Int = 0

    var incomeType: IncomeType? = null

    var expenseCategoryType: ExpenseCategoryTypeEnum? = null

    var destinationAccount: Int? = null
}

class IncomeType {

}
