package com.example.businesscontrollv3.model

enum class TransactionTypeEnum(val type:String) {

    EXPENSE("Despesa"),
    INCOME("Receita"),
    TRANSFER("Transferencia");

}