package com.example.businesscontrollv3.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.businesscontrollv3.BusinessControllV3
import com.example.businesscontrollv3.repository.AccountRepository

class AccountViewModel(val accountRepository:AccountRepository):BaseViewModel() {

    val accountList = accountRepository.getAccounts()




}