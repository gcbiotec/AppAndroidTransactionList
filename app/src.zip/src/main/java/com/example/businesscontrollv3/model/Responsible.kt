package com.example.businesscontrollv3.model

data class Responsible(val name:String) {




}