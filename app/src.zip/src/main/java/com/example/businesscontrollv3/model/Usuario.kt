package com.example.businesscontrollv3.model

data class Usuario(val email: String, val password: String)