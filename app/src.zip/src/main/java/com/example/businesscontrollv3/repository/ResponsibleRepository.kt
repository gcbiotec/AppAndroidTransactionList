package com.example.businesscontrollv3.repository

import android.content.Context
import com.example.businesscontrollv3.model.Responsible
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class ResponsibleRepository(val context: Context) {

    val gson: Gson = Gson()

    private fun getSharedPref() =
            context.getSharedPreferences("RESPONSIBLES_KEY", Context.MODE_PRIVATE)?:
            throw Exception("KEY INVALID")

    fun getResponsibles(): MutableList<Responsible>{
        val sharedPref = getSharedPref()

        //Pegar arquivo para leitura e escrita
        val stringResponsibles = sharedPref.getString("RESPONSIBLES_KEY", "")

        val type: Type = object : TypeToken<List<Responsible>>() {}.type

        return if (stringResponsibles.isNullOrEmpty())
            mutableListOf()
        else
            gson.fromJson(stringResponsibles, type)
    }

    fun save(responsible : Responsible){
        val sharedPref = getSharedPref()

        val responsibles = getResponsibles()

//        val type: Type = object : TypeToken<List<Responsible>>() {}.type
//        val responsibles: MutableList<Responsible> = if (stringResponsibles.isNullOrEmpty()) mutableListOf()
//        else gson.fromJson(stringResponsibles, type)
//        val responsible = Responsible(name)

        responsibles.add(responsible)

        with(sharedPref.edit()){
            putString("responsibles", gson.toJson(responsibles))
            commit()
        }
    }
    companion object{
        const val RESPONSIBLE_KEY = "RESPONSIBLES"
    }
}