package com.example.businesscontrollv3.model

data class Login(val email: String, val password: String)

