package com.example.businesscontrollv3.model

enum class AccountTypeEnum(val type: String) {
    DEBITO( "Débito"),
    CREDITO("Crédito")

}
