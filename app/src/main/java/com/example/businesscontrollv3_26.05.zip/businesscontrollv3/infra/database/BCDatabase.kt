package com.example.businesscontrollv3.infra.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.businesscontrollv3.model.Responsible

@Database(entities = [Responsible::class], version = 1, exportSchema = false)
abstract class BCDatabase : RoomDatabase() {

    abstract fun responsibleDAO(): ResponsibleDAO

    companion object {
        @Volatile
        private var INSTACE: BCDatabase? = null
        fun getDatabase(context: Context): BCDatabase {
            return INSTACE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BCDatabase::class.java,
                    "BCDatabase"
                ).build()

                INSTACE = instance
                instance
            }
        }
    }
}