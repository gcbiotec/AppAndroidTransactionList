package com.example.businesscontrollv3.model.type

class IncomeType {
}